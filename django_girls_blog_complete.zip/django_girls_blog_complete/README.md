# Django Girls Blog Assignment

This project completes the requested Django Girls Tutorial sections:

- Extend Your Application
- Django Forms
- Homework: secure your website
- Homework: add more to your website
- Homework: create comment model
- Domain section is informational only, so no paid domain is included.

## How to run in VS Code on Windows

1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open the VS Code terminal.
4. Create a virtual environment:

```bash
python -m venv myvenv
```

5. Activate the virtual environment:

```bash
myvenv\Scripts\activate
```

6. Install Django:

```bash
pip install -r requirements.txt
```

7. Create the database tables:

```bash
python manage.py makemigrations
python manage.py migrate
```

8. Create an admin user:

```bash
python manage.py createsuperuser
```

9. Run the website:

```bash
python manage.py runserver
```

10. Open this URL in your browser:

```text
http://127.0.0.1:8000/
```

## Main pages

- Home / published posts: `http://127.0.0.1:8000/`
- Admin panel: `http://127.0.0.1:8000/admin/`
- Login: `http://127.0.0.1:8000/accounts/login/`
- New post: `http://127.0.0.1:8000/post/new/`
- Draft posts: `http://127.0.0.1:8000/drafts/`

## Features included

- Blog post model
- Comment model
- Admin registration for posts and comments
- Post form for creating and editing posts
- Comment form for reader comments
- Draft posts
- Publish button
- Delete post button
- Login/logout
- Login protection for add, edit, draft list, publish, delete, approve comment, and remove comment
- Approved comments visible to visitors
- Unapproved comments visible only to logged-in users
