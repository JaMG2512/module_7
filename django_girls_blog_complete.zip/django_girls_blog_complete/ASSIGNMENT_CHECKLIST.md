# Assignment Checklist

## Main Django Girls Tutorial

### Extend Your Application
Completed:
- Blog app included.
- Post model included.
- Post list and detail pages included.
- URL routing included.
- Templates included.
- Static CSS included.

### Django Forms
Completed:
- `blog/forms.py` created.
- `PostForm` created using `forms.ModelForm`.
- Create post page added at `/post/new/`.
- Edit post page added at `/post/<pk>/edit/`.
- CSRF token included in forms.
- Forms save data to the database.

## Django Girls Tutorial Extensions

### Homework: secure your website
Completed:
- `login_required` protects create/edit/drafts/publish/delete actions.
- Login page configured at `/accounts/login/`.
- Logout configured at `/accounts/logout/`.
- Base template shows login button for anonymous users.
- Base template shows user greeting and logout for logged-in users.

### Homework: add more to your website
Completed:
- New posts are saved as drafts first.
- Draft list added at `/drafts/`.
- Publish button added to draft post detail pages.
- Delete button added to post detail pages.

### Homework: create comment model
Completed:
- `Comment` model created.
- Comment connected to Post with a ForeignKey.
- Comment registered in admin.
- Comment display added to post detail pages.
- `CommentForm` added.
- Add comment page added.
- Approve/remove comment features added.
- Only approved comments show publicly.

### Domain
The assignment says this section is informational only. No domain purchase is included or required.
